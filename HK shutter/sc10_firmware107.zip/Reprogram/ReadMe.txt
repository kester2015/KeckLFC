Close any applications that may be communciating to the device on your PC.
Extract all files into a directory on the hard drive of the PC.
With the device connected to a Serial port on your PC and turned on, run Reprogram.exe.
A dialog box should be displayed with a progress bar.  The progress bar should indicate the status of 3 phases of the update and once complete will automatically close.
The firmware update will now be complete.