This folder contains:
 (1) Thorlabs End-user License Agreement.
 (2) License of open source library used in Thorlabs Product.